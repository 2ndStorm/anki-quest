<div align="center">
<h1>◆ Anki Quest — Gamified Reviews</h1>
<p><b>Turn your daily reviews into a game: XP, levels, combos, bosses, quests, a base to build and a companion to raise, across 23 themes.</b></p>
<p>Anki Quest never touches Anki's scheduling. Your cards are scheduled exactly as they would be without it.</p>
<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/dashboard.png" width="900" alt="The Anki Quest main screen: a Continue studying button, today's progress, the deck list, your level and status, the weekly raid and daily quests">
</div>

---

## 🚀 Quick start

1. **Install** the add-on and **restart Anki**.
2. **Click Continue studying** on the main screen, or open any deck as usual, and review.
3. **Change anything** in **Tools → Anki Quest: Settings…** (the add-on's **Config** button opens the same window).

Click **◆ LV** in the top toolbar at any time to open your stats, base, quests, trophies and loot.

---

## 🖱️ Review with your mouse

<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/mouse-controls.webp" width="720" alt="Animation: left click shows the answer and rates Good; scrolling up rates Easy, scrolling down rates Hard, and right click rates Again">

Mouse answering is **on by default**. Anki's own keys (Space and 1–4) and buttons still work too.

| Where | Action | Result |
|---|---|---|
| Question side | **Left click** | Show the answer |
| Question side | **Right click** | Undo the last answer |
| Answer side | **Left click** | **Good** |
| Answer side | **Right click** | **Again** |
| Answer side | **Scroll up** | **Easy** |
| Answer side | **Scroll down** | **Hard** |
| Anywhere | **Double middle-click** | Turn mouse answering off / on (a small tag shows while it's off) |

**Good to know**

- **Nothing happens by accident:** clicks on links, buttons, audio players and typing boxes are left alone, and mouse input is ignored for 0.4 s after a card or answer appears, so a double click can't reveal and rate in one go.
- **Long cards scroll normally.** The wheel only rates the card once you reach the top or bottom.
- **Selecting text** and right-clicking always gives the normal Copy menu.
- **🔎 Search Google from a card:** with mouse answering off (double middle-click, or in Settings), select text, right-click and choose **Search Google for "…"**. The search opens in your web browser.
- **Trackpad too sensitive?** Raise `mouse_scroll_threshold` in the full settings file (Settings → General → *Open the full settings file*).

---

## ⌨️ Keyboard shortcuts

| Key | What it does |
|---|---|
| <kbd>P</kbd> | Pause the recall timer and hide the card (click anywhere to resume) |
| <kbd>Shift</kbd>+<kbd>P</kbd> | Pause the timer but keep the card on screen |
| <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>T</kbd> | Next theme / switch light and dark |
| <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>M</kbd> | Mute / unmute all sounds |
| <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>L</kbd> | Performance mode (lighter effects for slower computers) |
| <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>B</kbd> | Blue-light filter for night-time reviewing |
| <kbd>/</kbd> | Search your decks (main screen) |
| <kbd>Ctrl</kbd>+<kbd>F</kbd> | Search the settings (Settings window) |

On a Mac use <kbd>Cmd</kbd> instead of <kbd>Ctrl</kbd>. Every key can be changed in **Settings → General**.

---

## 🎯 The review screen

<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/review-screen.png" width="900" alt="The review screen with numbered labels on each part">

1. **Level, rank and XP.** The tag shows your current aura stage.
2. **Combo, day streak and daily goal** (cards today / goal).
3. **Recall timer:** how fast you remembered (Lightning, Quick, On time or Overtime), plus the two pause buttons.
4. **Today's boss.** Correct answers hit it, and an Again lets it heal a little.
5. **The weekly raid boss.**
6. **Your companion.** Click it to say hello.
7. **Your aura,** a glow around the cursor and the screen edges that grows with your streak.
8. **Anki's answer buttons,** which still work as normal.

The badge shrinks out of the way when it would cover card text, and your card always stays readable: clozes, tables, images and image occlusion are all restyled to match the theme.

---

## ⚡ XP, combos and the aura

<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/combo-and-aura.webp" width="720" alt="Animation: a run of quick correct answers builds the combo to ten (OVERCLOCK) while the aura grows from SYNCED to OVERDRIVE">

- **XP for every answer:** Again 2 · Hard 6 · Good 10 · Easy 12, plus 5 the first time you see a new card.
- **Recall timer:** remember within **4 s** for a **Lightning** bonus (×1.5 XP) or **8 s** for **Quick** (×1.25, both on Good or Easy). After **20 s** you're in **Overtime** (×0.5). New cards get twice as long.
- **Combo:** +10 % XP for every 10 cards in a row (up to +50 %), with milestone effects and bonus XP at 5, 10, 50 and 100. An Again or Overtime breaks it.
- **Day streak:** answer 20 cards a day to keep it going, for +2 % XP per day (up to +30 %).
- **Daily goal:** 100 cards for a +100 XP bonus. You can set your own extra target with **Tools → Anki Quest: Set custom goal…**
- **The aura** builds faster with quick answers and evolves through five stages: **SYNCED → AMPED → OVERDRIVE → HYPERDRIVE → GODMODE**. The top stage sets off **fever**: double XP and boss damage for a few cards.

> **Always rate honestly.** Again still earns XP, and the add-on never changes when you see a card, so a wrong "Good" only costs you real learning. Every number above can be changed in Settings.

---

## 🏰 Bosses, loot, quests and your base

<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/base-and-companion.png" width="440" alt="The base tab: your buildings, their upgrades and your companion"> <img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/raid-and-quests.png" width="440" alt="The quests tab: the weekly raid and daily and weekly quests">

- **Daily boss:** a new one every day, each tougher than the last, with XP and a loot chest for every kill.
- **Loot chests** drop from correct answers. They hold bonus XP plus items (XP potions, a Combo Shield, an Hourglass for more recall time, a Streak Freeze…), colour schemes for your trail and aura, and titles to wear next to your rank.
- **Quests:** three daily and three weekly quests, each paying XP as soon as you finish it.
- **Weekly raid:** one huge boss for the whole week. Your weakest deck that week is its weak spot, and reviewing it does double damage.
- **Your base:** earn materials from reviews and spend them on 8 buildings, each with 3 levels and a perk (more XP, more loot, faster companion growth…).
- **Your companion** hatches after your first 20 correct answers, grows through five stages and reacts to how you're doing. Each theme has its own: a robot, a dragon, an owl…
- **Prestige** at level 50: start again at level 1, keep everything else, and earn a star and a permanent XP bonus.
- **Medals and a trophy room** keep track of your records.

---

## 🏠 A better main screen

- **Continue studying** picks your current deck, or your busiest one if it has nothing due.
- **Today at a glance:** daily goal ring, cards, accuracy, minutes studied, XP and streak. You get a warning when your streak is at risk.
- **Deck list** with a hover **Study** button, search (<kbd>/</kbd>), **+ Deck** and **Import**.
- **14-day forecast** of upcoming reviews, and a **review heatmap**. Click a day to open those cards in the Browser.

Prefer Anki's usual layout? Turn off **Dashboard main screen** in Settings.

---

## 🎨 23 themes

<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/themes.png" width="900" alt="Twelve of the themes on the review screen">

Cyberpunk · Space · Pirate · Fantasy · Retro arcade · **Vitals** (with medical ranks from Fresher to Consultant) · Zen · Steampunk · Frontline · Hunter's Moon · Homestead · Neon Noir · Poker Night · Iron Crusade · Grimdark · Deep Sea · Rainforest · Laboratory · Encore · Atelier · Halloween · Frostlands · Grand Library

Each theme has its own animated scene, colours, fonts, sounds, rank ladder, bosses, companion and words, in **dark and light** versions. Switch from the **Themes** button on the main screen, **Tools → Anki Quest: Theme**, or <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>T</kbd>.

---

## ⚙️ Settings

<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/settings.png" width="900" alt="The settings window with theme buttons, trail styles and a live preview">

Open **Tools → Anki Quest: Settings…** to change every value with a **live preview**. <kbd>Ctrl</kbd>+<kbd>F</kbd> finds any setting.

- **Your look, per theme:** 24 trail styles, 25 aura styles, colour schemes and a "daily progress" picture that fills up as you review.
- **Your rules:** XP, timer limits, combo rules, goal size, boss toughness, loot chance…
- **Comfort:** performance mode, a blue-light filter (on a timer if you like), the moving background's speed, and switches for sounds, pop-ups, confetti and the themed card.
- **Simpler effects:** if your computer's "reduce motion" setting is on, effects are simplified automatically.

---

## 📊 Stats

<img src="https://raw.githubusercontent.com/YOUR-GITHUB-NAME/anki-quest/main/images/stats.png" width="600" alt="The stats window: rank, field stats, recall timer records and the review heatmap">

Click **◆ LV** in the toolbar (or **Tools → Anki Quest: Stats & medals**) for your rank, records, recall-timer stats, review heatmap, base, quests, trophy room and loot.

---

## 📱 On your phone (AnkiDroid)

**Tools → Anki Quest: Phone version (AnkiDroid)…** adds a light version of Anki Quest to your card templates, then you sync. On the phone:

- **Tap** to show the answer.
- **Swipe** left for Again, right for Good, up for Easy and down for Hard.

Reviews from your phone, AnkiWeb or another computer count towards your progress on the desktop at the next sync.

---

## 🧪 Try it safely

**Tools → Anki Quest: Developer / test mode** opens a test deck with every card type. Nothing you do there changes your progress, and a test panel lets you set off any effect or sound.

---

## ℹ️ Details

- **Works with** Anki desktop, built and used on Anki 26.09. It needs Anki 2.1.50 or later.
- **Your progress** is saved per profile in the add-on's folder and is kept when the add-on updates.
- **Privacy:** Anki Quest doesn't connect to the internet. The only exception is Search Google, which opens your own web browser when you choose it.
- **Plays well with others:** it changes how Anki looks, not how it works. If another add-on also restyles Anki's screens, turn off **Themed review card** in Settings, or `theme_main_screens` in the full settings file.
- **Licence:** AGPL-3.0. Fonts are under the SIL Open Font License. All art is drawn by code and all sounds are synthesised live.

**Found a bug or have an idea?** Use the **Contact Author** button on this page.
